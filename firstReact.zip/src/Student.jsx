import React, { Component } from 'react';

const candidate=["1","2","3"];
const candidate1=["4","5","6"];
const candidate2=["7","8","9"];
class Student extends Component {
 constructor(props) {
 super(props);
 this.state = {
 nameStudent: candidate
 };

 this.onClick = this.onClick.bind(this);
 this.onClick1 = this.onClick1.bind(this);
 }

 onClick() {
   if(this.state.nameStudent === candidate)
   {
 this.setState({nameStudent: candidate1});
   }
   else if(this.state.nameStudent === candidate1)
   {
 this.setState({nameStudent: candidate2});
   }
   else if(this.state.nameStudent === candidate2)
   {
      this.setState({nameStudent: candidate});
   }
 }
 onClick1() {
 this.setState({nameStudent: candidate2});
 }
 
 render() {
 return (
 <>
    <ul>
    {this.state.nameStudent.map((name)=>
    <li>{name}</li>
    )}
    </ul>
 <button onClick={this.onClick}>update</button>
 <button onClick={this.onClick1}>update1</button>
 </>
 );
 }
}
export default Student;
