import './App.css';
import Student from './Student'

function App() {
  // const candidate=["Suresh","Ramesh","satish","raj","nisha","shobha"];

  return (
    <>
    <Student />
    </>
  );
}

export default App;
{/* <ul>
{candidate.map((name)=>
<li>{name}</li>
)}
</ul> */}
